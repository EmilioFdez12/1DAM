package prog.unidad04.practica406.libreria;

public interface ConvertibleATexto {

  /**
   * @param Obtiene una cadena con la información del objeto en formato texto
   * @return Cadena con la información del objeto en formato texto
   */
  String aTexto();
    
}
