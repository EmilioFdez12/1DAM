package prog.unidad04.practica406.libreria;

public class FechaException extends RuntimeException {
  
}
