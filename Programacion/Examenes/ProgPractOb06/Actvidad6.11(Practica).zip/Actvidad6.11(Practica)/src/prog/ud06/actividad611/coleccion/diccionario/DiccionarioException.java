package prog.ud06.actividad611.coleccion.diccionario;

import java.io.Serializable;

/**
 * Excepción de diccionario
 */
public class DiccionarioException extends RuntimeException implements Serializable {
	private static final long serialVersionUID = 1L;

		public DiccionarioException(){    
    }
}
