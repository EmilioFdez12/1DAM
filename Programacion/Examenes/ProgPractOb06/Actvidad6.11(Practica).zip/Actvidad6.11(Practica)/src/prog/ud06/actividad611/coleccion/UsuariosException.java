package prog.ud06.actividad611.coleccion;

import java.io.Serializable;

/**
 * Excepción lanzada por el contenedor de usuarios
 */
public class UsuariosException extends RuntimeException implements Serializable {
	private static final long serialVersionUID = 1L;

}
